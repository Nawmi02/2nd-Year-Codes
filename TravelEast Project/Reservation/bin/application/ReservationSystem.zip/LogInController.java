package application;


import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import uap.DataHandler;

public class LogInController {
	 @FXML
	    private TextField userTf;
	 @FXML 
		private TextField nameTf;
		
	@FXML 
		private TextField ageTf;
		
	@FXML 
		private CheckBox adminCB;
	@FXML
        private Button LogIn;
	@FXML 
	    private Button SignUp;
	
	public void LogIn(ActionEvent event) throws IOException {
		String userID=userTf.getText();
		if(userID.startsWith("11-")) {
			Pane root = FXMLLoader.load(getClass().getClassLoader().getResource("application/AdminViewAno.fxml"));
			Scene scene = new Scene(root);			
			Main.stage.setScene(scene);
			Main.stage.show();
		}
		else if(userID.startsWith("22-")) {
			Pane root = FXMLLoader.load(getClass().getClassLoader().getResource("application/CustomerView1.fxml"));
			Scene scene = new Scene(root);			
			Main.stage.setScene(scene);
			Main.stage.show();
		}
	}
	public void SignUp(ActionEvent event) throws IOException{
		String name=nameTf.getText();
		String ageText = ageTf.getText();
		int age=Integer.parseInt(ageText);
		boolean isAdmin = adminCB.isSelected();
		Main.Items.addUser(name,age,isAdmin);
		DataHandler.saveData(Main.Items);
		
		if(isAdmin) {
			Pane root = FXMLLoader.load(getClass().getClassLoader().getResource("application/AdminViewAno.fxml"));
			Scene scene = new Scene(root);			
			Main.stage.setScene(scene);
			Main.stage.show();
		}
		else {
			Pane root = FXMLLoader.load(getClass().getClassLoader().getResource("application/CustomerView1.fxml"));
			Scene scene = new Scene(root);			
			Main.stage.setScene(scene);
			Main.stage.show();
		}

	}

}
